// High-definition Pixel-Art Sprite Sheet Renderer for "Misión: Nosotros"
// Recorta los frames directamente desde /assets/sprites/spritesheet.png usando las coordenadas exactas de source rect (sx, sy, sw, sh)

export interface JacksonSpriteOptions {
  facingLeft?: boolean;
  isKicking?: boolean;
  isJumping?: boolean;
  isHurt?: boolean;
  isVictory?: boolean;
  isWedding?: boolean;
  isWalking?: boolean;
  frameCount?: number;
}

export interface CarlosSpriteOptions {
  hitFlash?: boolean;
  isTossing?: boolean;
  isDefeated?: boolean;
  frameCount?: number;
}

export interface PigeonSpriteOptions {
  isOnGround?: boolean;
  isFlying?: boolean;
  isFalling?: boolean;
  isDestroyed?: boolean;
  frameCount?: number;
}

export interface ElizaSpriteOptions {
  isWalking?: boolean;
  isReunion?: boolean;
  isWedding?: boolean;
  frameCount?: number;
}

// Cargar la imagen del PNG Sprite Sheet
let spriteSheetImage: HTMLImageElement | null = null;

function getSpriteSheet(): HTMLImageElement | null {
  if (typeof window === 'undefined') return null;
  if (!spriteSheetImage) {
    spriteSheetImage = new Image();
    spriteSheetImage.src = '/assets/sprites/spritesheet.png';
  }
  return spriteSheetImage.complete ? spriteSheetImage : null;
}

/**
 * Jackson Sprite Renderer (Crop from PNG using exact sx, sy, sw, sh)
 */
export function drawJacksonSprite(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  width: number,
  height: number,
  options: JacksonSpriteOptions = {}
) {
  const {
    facingLeft = false,
    isKicking = false,
    isJumping = false,
    isHurt = false,
    isVictory = false,
    isWedding = false,
    isWalking = false,
    frameCount = 0,
  } = options;

  const sheet = getSpriteSheet();

  // Exact Source Bounding Box Coordinates (sx, sy, sw, sh)
  let sx = 8;
  let sy = 2;
  let sw = 48;
  let sh = 94;

  if (isWedding) {
    sx = 456; sy = 2; sw = 48; sh = 94;
  } else if (isVictory) {
    sx = 386; sy = 2; sw = 60; sh = 94;
  } else if (isHurt) {
    sx = 328; sy = 6; sw = 40; sh = 90;
  } else if (isKicking) {
    sx = 264; sy = 4; sw = 56; sh = 92;
  } else if (isJumping) {
    sx = 200; sy = 0; sw = 48; sh = 90;
  } else if (isWalking) {
    const frame = Math.floor(frameCount / 6) % 2;
    if (frame === 0) {
      sx = 72; sy = 2; sw = 48; sh = 94;
    } else {
      sx = 136; sy = 2; sw = 48; sh = 94;
    }
  } else {
    // Idle
    sx = 8; sy = 2; sw = 48; sh = 94;
  }

  ctx.save();
  ctx.imageSmoothingEnabled = false;

  const walkBob = isWalking ? Math.abs(Math.sin(frameCount * 0.3)) * 3 : 0;
  const renderY = y - walkBob;

  if (sheet) {
    if (facingLeft) {
      ctx.translate(x + width, renderY);
      ctx.scale(-1, 1);
      ctx.drawImage(sheet, sx, sy, sw, sh, 0, 0, width, height);
    } else {
      ctx.drawImage(sheet, sx, sy, sw, sh, x, renderY, width, height);
    }
  } else {
    ctx.fillStyle = isWedding ? '#ffffff' : '#2563eb';
    ctx.fillRect(x, renderY, width, height);
  }

  ctx.restore();
}

/**
 * Carlos (Boss) Sprite Renderer (Crop from PNG using exact sx, sy, sw, sh)
 */
export function drawCarlosSprite(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  width: number,
  height: number,
  options: CarlosSpriteOptions = {}
) {
  const { hitFlash = false, isTossing = false, isDefeated = false, frameCount = 0 } = options;

  const sheet = getSpriteSheet();

  let sx = 6;
  let sy = 96;
  let sw = 52;
  let sh = 94;

  if (isDefeated) {
    sx = 198; sy = 122; sw = 58; sh = 48;
  } else if (hitFlash) {
    sx = 134; sy = 96; sw = 52; sh = 94;
  } else if (isTossing) {
    sx = 72; sy = 96; sw = 56; sh = 94;
  } else {
    // Idle
    sx = 6; sy = 96; sw = 52; sh = 94;
  }

  ctx.save();
  ctx.imageSmoothingEnabled = false;

  const breathY = y + (isDefeated ? 0 : Math.sin(frameCount * 0.1) * 1.5);
  const renderHeight = isDefeated ? height * 0.5 : height;
  const renderY = isDefeated ? y + height * 0.5 : breathY;

  if (sheet) {
    ctx.drawImage(sheet, sx, sy, sw, sh, x, renderY, width, renderHeight);
  } else {
    ctx.fillStyle = hitFlash ? '#ef4444' : '#374151';
    ctx.fillRect(x, renderY, width, renderHeight);
  }

  ctx.restore();
}

/**
 * Paloma / Pigeon Sprite Renderer (Crop from PNG using exact sx, sy, sw, sh)
 */
export function drawPigeonSprite(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  options: PigeonSpriteOptions
) {
  const { isOnGround, isFlying, isFalling, isDestroyed, frameCount = 0 } = options;

  const sheet = getSpriteSheet();

  let sx = 0;
  let sy = 290;
  let sw = 36;
  let sh = 40;

  if (isDestroyed) {
    sx = 146; sy = 290; sw = 44; sh = 38;
  } else if (isOnGround) {
    sx = 98; sy = 298; sw = 36; sh = 36;
  } else if (isFalling) {
    sx = 50; sy = 294; sw = 44; sh = 40;
  } else {
    // Flying
    sx = 0; sy = 290; sw = 36; sh = 40;
  }

  ctx.save();
  ctx.imageSmoothingEnabled = false;

  const size = isDestroyed ? 44 : 36;
  const peckY = y + (isOnGround ? Math.sin(frameCount * 0.2) * 2 : Math.sin(frameCount * 0.4) * 4);

  if (sheet) {
    ctx.drawImage(sheet, sx, sy, sw, sh, x - size / 2, peckY - size / 2, size, size);
  } else {
    ctx.fillStyle = '#9ca3af';
    ctx.fillRect(x - 10, peckY - 6, 20, 12);
  }

  ctx.restore();
}

/**
 * Eliza Sprite Renderer (Crop from PNG using exact sx, sy, sw, sh)
 */
export function drawElizaSprite(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  width: number,
  height: number,
  options: ElizaSpriteOptions = {}
) {
  const { isWalking = false, isReunion = false, isWedding = false, frameCount = 0 } = options;

  const sheet = getSpriteSheet();

  let sx = 10;
  let sy = 194;
  let sw = 44;
  let sh = 92;

  if (isWedding) {
    sx = 266; sy = 194; sw = 44; sh = 92;
  } else if (isReunion) {
    sx = 194; sy = 194; sw = 60; sh = 92;
  } else if (isWalking) {
    const frame = Math.floor(frameCount / 6) % 2;
    if (frame === 0) {
      sx = 74; sy = 194; sw = 44; sh = 92;
    } else {
      sx = 138; sy = 194; sw = 44; sh = 92;
    }
  } else {
    // Idle
    sx = 10; sy = 194; sw = 44; sh = 92;
  }

  ctx.save();
  ctx.imageSmoothingEnabled = false;

  if (sheet) {
    ctx.drawImage(sheet, sx, sy, sw, sh, x, y, width, height);
  } else {
    ctx.fillStyle = isWedding ? '#ffffff' : '#3b82f6';
    ctx.fillRect(x, y, width, height);
  }

  ctx.restore();
}

/**
 * Peruvian Passport Stamp Sprite
 */
export function drawTravelStampSprite(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  width: number,
  height: number
) {
  ctx.save();
  ctx.shadowColor = '#f59e0b';
  ctx.shadowBlur = 15;

  ctx.fillStyle = '#fef08a';
  ctx.fillRect(x - 3, y - 3, width + 6, height + 6);

  ctx.fillStyle = '#d97706';
  ctx.fillRect(x, y, width, height);

  ctx.fillStyle = '#1d4ed8';
  ctx.fillRect(x + 4, y + 4, width - 8, height - 8);

  ctx.fillStyle = '#ef4444';
  ctx.fillRect(x + 6, y + 6, 8, height - 12);
  ctx.fillRect(x + width - 14, y + 6, 8, height - 12);
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(x + 14, y + 6, width - 28, height - 12);

  ctx.fillStyle = '#1e3a8a';
  ctx.font = 'bold 12px monospace';
  ctx.fillText('PERÚ', x + 10, y + 26);

  ctx.restore();
}

/**
 * Pixel Airplane Sprite
 */
export function drawAirplaneSprite(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  width: number,
  height: number
) {
  ctx.save();

  ctx.fillStyle = '#f8fafc';
  ctx.fillRect(x, y + 8, width, 12);
  ctx.fillStyle = '#cbd5e1';
  ctx.fillRect(x, y + 16, width, 4);

  ctx.fillStyle = '#38bdf8';
  ctx.fillRect(x + width - 12, y + 8, 10, 6);

  ctx.fillStyle = '#0284c7';
  ctx.fillRect(x + 12, y + 10, 4, 3);
  ctx.fillRect(x + 20, y + 10, 4, 3);
  ctx.fillRect(x + 28, y + 10, 4, 3);

  ctx.fillStyle = '#ef4444';
  ctx.fillRect(x - 8, y + 2, 10, 12);

  ctx.fillStyle = '#94a3b8';
  ctx.fillRect(x + 18, y - 6, 12, 26);
  ctx.fillStyle = '#64748b';
  ctx.fillRect(x + 22, y - 6, 4, 26);

  ctx.fillStyle = '#38bdf8';
  ctx.fillRect(x - 14, y + 12, 6, 4);

  ctx.restore();
}

/**
 * Glowing Pixel Heart Sprite
 */
export function drawGlowingHeartSprite(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  frameCount: number
) {
  ctx.save();
  ctx.shadowColor = '#ef4444';
  ctx.shadowBlur = 20;

  const pulse = Math.sin(frameCount * 0.1) * 2;

  ctx.fillStyle = '#ef4444';
  ctx.beginPath();
  ctx.arc(x, y, 14 + pulse, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 16px sans-serif';
  ctx.fillText('♥', x - 6, y + 5);

  ctx.restore();
}
